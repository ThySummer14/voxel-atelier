# 夜航 · 潮汐终点站

实时 Three.js 体素作品。整个世界由程序化三维几何构成；没有 Blender、图片贴景或远程 CDN。

## 直接打开

双击「夜航·潮汐终点站.html」即可离线运行。需要支持 WebGL 2 的现代浏览器和硬件加速。全部脚本与样式已内嵌，不需要服务器或网络。

也可以用任意静态服务器打开 dist/index.html。

## 操作

- 拖动 / 单指：环视；滚轮 / 双指：缩放
- 环游：自动缓慢环绕
- 暂停：停止列车、船只、潮汐与自动环游
- 归位：恢复精心设定的初始视角
- 夜色 / 晨曦 / 白昼：切换光影
- 精细 / 轻盈：切换阴影、辉光和像素比
- 留影：保存不含界面的 PNG
- 键盘：空格暂停，R 归位

系统开启「减少动态效果」时，默认停止环境动画。页面切换到后台会停止绘制。

## 修改源码

scene.js 为可读场景源码；dist/style.css 为界面样式。

需要 Node.js 20 或更新版本：

    npm install
    npm run build
    npm run check

源代码使用固定版本 Three.js 0.180.0 / esbuild 0.25.10。发布文件已包含 Three.js，不需要安装依赖即可游览。修改后可通过 build-portable.py 重新生成单文件离线版。

Three.js 以 MIT License 发布，见 dist/THREE-LICENSE.txt。作品源码以本文件同目录 LICENSE.txt 授权。
