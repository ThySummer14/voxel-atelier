import * as THREE from 'three';
import fs from 'node:fs';
import assert from 'node:assert/strict';
let src=fs.readFileSync('scene.js','utf8').replace(/^import .*;$/gm,'');
src=src.slice(0,src.indexOf('\ntry{\nscene='));
const document={createElement(){return {width:0,height:0,getContext(){return {fillRect(){},strokeRect(){},fillText(){}}}}},querySelector(){return null}};
const run=new Function('THREE','document','matchMedia','innerWidth',src+`\nscene=new THREE.Scene();ground();station();railway();landscape();ocean();sky();flush();return {scene,pools,anim};`);
const {scene,pools,anim}=run(THREE,document,()=>({matches:false}),1440);
let count=0;for(const [kind,boxes] of pools){for(const b of boxes){assert(b.slice(0,6).every(Number.isFinite));assert(b[3]>0&&b[4]>0&&b[5]>0);}count+=boxes.length;}
for(let t=0;t<260;t+=2)for(const f of anim)f(t);
const camera=new THREE.OrthographicCamera(-57.6,57.6,36,-36,.1,450);camera.position.set(64,45,70);camera.lookAt(0,13,0);camera.updateMatrixWorld();
const landmarks=[[-48,22,-24],[-30,8,21],[36,14,-10],[-4,40,-8],[-30,8,0],[30,8,0],[0,0,41]];
for(const [w,h] of [[1440,900],[390,844],[844,390],[1024,768]]){let aspect=w/h,vh=Math.max(72,88/aspect);Object.assign(camera,{left:-vh*aspect/2,right:vh*aspect/2,top:vh/2,bottom:-vh/2});camera.updateProjectionMatrix();for(const p of landmarks){const v=new THREE.Vector3(...p).project(camera);assert(Math.abs(v.x)<1&&Math.abs(v.y)<1,`landmark clipped ${w}×${h}: ${p} / ${v.toArray()}`);}}
const curve=new THREE.EllipseCurve(0,0,29,18,0,Math.PI*2,false,0),len=curve.getLength();let min=99,max=0;for(let i=0;i<200;i++){let p=curve.getPointAt(i/200),q=curve.getPointAt((i/200+5.65/len)%1),d=p.distanceTo(q);min=Math.min(min,d);max=Math.max(max,d);}assert(min>5.4);assert(max<5.8);
let objects=0;scene.traverse(o=>{if(o.isMesh||o.isPoints)objects++});console.log(JSON.stringify({passed:true,staticVoxelInstances:count,renderableObjects:objects,carriageCenterDistance:{min,max},framing:["1440×900","390×844","844×390","1024×768"],checks:["finite positive geometry","all animation callbacks","landmark framing","constant-arc-length carriage clearance"]},null,2));
